import os
from datetime import datetime

from airflow import DAG
from airflow.contrib.operators.dataflow_operator import DataflowTemplateOperator

from slack.slack_notification import alert_task_failure

etl_proj = os.environ["AIRFLOW_VAR_ETL_PROJ"]
region = os.environ["AIRFLOW_VAR_ETL_REGION"]
network = os.environ["AIRFLOW_VAR_COINAPI_NETWORK"]
subnet = os.environ["AIRFLOW_VAR_ETL_SUBNET"]
coin_sa_email = os.environ["AIRFLOW_VAR_COINAPI_SA_EMAIL"]
dflow_store = os.environ["AIRFLOW_VAR_ETL_DFLOW_STORE"]
dflow_code_bucket = os.environ["AIRFLOW_VAR_ETL_DFLOW_CODE_BUCKET"]

default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2020, 7, 13),
    "depends_on_past": True,
    "email_on_failure": False,
    "on_failure_callback": alert_task_failure,
    "dataflow_default_options": {
        "project": f"{etl_proj}",
        "region": f"{region}",  # run in us-west1 because source bucket is there
        "network": f"{network}",
        "subnetwork": f"regions/{region}/subnetworks/{subnet}",
        "machineType": "n1-standard-4",
        "numWorkers": 8,
        "maxWorkers": 32,
        "serviceAccountEmail": f"{coin_sa_email}@{etl_proj}.iam.gserviceaccount.com",
        "tempLocation": f"gs://{dflow_store}/coinapi/orderbook/tmp",
    },
}

with DAG(
    "coinapi_orderbook_snapshots_restatement__v1",
    default_args=default_args,
    schedule_interval="30 0 * * *",
) as dag:
    run_snapshots_to_bigquery_template = DataflowTemplateOperator(
        task_id="coinapi-orderbook-restate",
        template=f"gs://{dflow_code_bucket}/templates/us-we1/coinapi/orderbook/orderbook-snapshot-to-bigquery-v4",
        dataflow_default_options=default_args["dataflow_default_options"],
        parameters={
            "inputPrefix": "gs://ripple-q78eq51mn7-coinapi",
            "startDate": "{{ macros.ds_add(ds, -7) }}",
            "endDate": "{{ macros.ds_add(ds, -7) }}",
            "outputTableSpec": f"{etl_proj}:coinapi.orderbook_snapshot_50",
            "fileFailureTableSpec": f"{etl_proj}:coinapi.orderbook_snapshot_50_file_failures",
        },
        retries=1,
        retry_exponential_backoff=True,
    )
