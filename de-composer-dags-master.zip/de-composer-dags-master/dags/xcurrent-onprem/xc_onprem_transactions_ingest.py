import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.contrib.operators.dataflow_operator import DataFlowJavaOperator
from airflow.contrib.operators.gcs_list_operator import GoogleCloudStorageListOperator
from airflow.operators.bash_operator import BashOperator

from slack.slack_notification import alert_task_failure

etl_proj = os.environ["AIRFLOW_VAR_ETL_PROJ"]
region = os.environ["AIRFLOW_VAR_ETL_REGION"]
subnet = os.environ["AIRFLOW_VAR_ETL_SUBNET"]
xc_onprem_sa_email = os.environ["AIRFLOW_VAR_XC_ONPREM_SA"]
dflow_store = os.environ["AIRFLOW_VAR_ETL_DFLOW_STORE"]
dflow_code_bucket = os.environ["AIRFLOW_VAR_ETL_DFLOW_CODE_BUCKET"]
dflow_kms_key = os.environ["AIRFLOW_VAR_ETL_DFLOW_KMS_KEY"]

######################################################
# Tasks in the DAG are
# 1. Import xC on-prem data from impala and upload to GCS
# 2. List the file in the GCS bucket
# 3. Ingest the file to BQ
######################################################

# Jars
impala_importer_jar = "impala-importer-1.0.0.jar"
xcurrent_etl_jar = "xcurrent-etl-1.2.0.jar"

### Input params for Impala-Importer ###

# Sql to execute
sql = "select data_date, report_id, previous_report_id, instance_id, version_number, runtime_mode, xc_user, \
source_domain, counterparty_domain, report_start_datetime, report_end_datetime, report_delivery_datetime, currency, \
value_payments_received, total_payments_received, value_payments_sent, total_payments_sent, \
value_return_payments_received, total_return_payments_received, value_return_payments_sent, \
total_return_payments_sent, payload, total_failed_payments, total_user_failed_payments, total_system_failed_payments, \
counterparty_currency, os_name, os_version, os_architecture, java_runtime_name, java_runtime_version, heap_max_size, \
heap_free_size, db_type, db_version, total_memory_size, receive_date from ripple.fact_xcurrent_transactions_vw \
where xc_user != '' and receive_date = '{{next_ds_nodash}}'"

# GCS bucket to upload
gcs_bucket = os.environ["AIRFLOW_VAR_XC_ONPREM_SRC_BUCKET"]

# Folder within GCS bucket
gcs_folder = "transactions/"

# Name of the file uploaded to GCS
output_file_name = "xc_onprem_transactions_{{next_ds_nodash}}.csv"

### End of input params for Impala-Importer ###

# Impala import command with placeholders
impala_import_command = 'java -jar /home/airflow/gcs/plugins/impala-importer/{} \
--sqlQuery "{}" --gcsBucket {} --gcsFolder {} --gcsFileName {}'

# Replace placeholders with parameters
impala_import_command = impala_import_command.format(
    impala_importer_jar, sql, gcs_bucket, gcs_folder, output_file_name
)

### Input params for BQ ingestion ###

input_source_bucket = os.environ["AIRFLOW_VAR_XC_ONPREM_SRC_BUCKET"]
archive_bucket = os.environ["AIRFLOW_VAR_ETL_ARCHIVE_BUCKET"]


### End of input params for BQ ingestion ###

default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2020, 8, 17),
    "depends_on_past": False,
    "email_on_failure": False,
    "on_failure_callback": alert_task_failure,
    "dataflow_default_options": {
        "project": f"{etl_proj}",
        "region": f"{region}",
        "tempLocation": f"gs://{dflow_store}/xcurrent/temp",
        "stagingLocation": f"gs://{dflow_store}/xcurrent/staging",
        "subnetwork": f"regions/{region}/subnetworks/{subnet}",
        "dataflowKmsKey": f"projects/{etl_proj}/locations/{region}/keyRings/{dflow_kms_key}/cryptoKeys/dataflow-pipeline-state-key",
        "serviceAccount": f"{xc_onprem_sa_email}@{etl_proj}.iam.gserviceaccount.com",
        "usePublicIps": "false",
    },
}

#  DAG definition
with DAG(
    "xc_onprem_transactions_ingest",
    default_args=default_args,
    schedule_interval="30 2 * * *",  # ETL in hadoop runs at 1.30 am, making the import run after that at 2.30 am
    catchup=False,
) as dag:
    # 1
    import_xc_onprem_transactions = BashOperator(
        task_id="import_xc_onprem_transactions",
        retries=3,
        retry_delay=timedelta(minutes=5),
        bash_command=impala_import_command,
    )

    # 2
    get_gcs_files = GoogleCloudStorageListOperator(
        task_id="get_gcs_files",
        bucket=input_source_bucket,
        prefix="transactions/xc_onprem_transactions",
        delimiter=".csv",
        google_cloud_storage_conn_id="google_cloud_default",
    )

    # 3
    xc_onprem_transactions_to_bq_ingest = DataFlowJavaOperator(
        task_id="xc_onprem_transactions_to_bq_ingest",
        jar="gs://" + dflow_code_bucket + "/xcurrent/" + xcurrent_etl_jar,
        job_class="com.ripple.data.beam.xcurrent.onprem.OnPremTransactionsIngest",
        dataflow_default_options=default_args["dataflow_default_options"],
        options={
            "inputBucket": "gs://" + input_source_bucket,
            "inputFileName": '{{ task_instance.xcom_pull(task_ids=["get_gcs_files"])[0][0] }}',
            "archiveBucket": "gs://" + archive_bucket,
        },
    )

# Import data from impala and ingest to BQ
import_xc_onprem_transactions >> get_gcs_files >> xc_onprem_transactions_to_bq_ingest
