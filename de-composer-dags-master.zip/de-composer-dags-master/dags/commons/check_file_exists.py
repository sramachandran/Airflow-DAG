def file_exists(**kwargs):
    xcom_value = (
        "{{  task_instance.xcom_pull(task_ids=[{}])[0][0] }}",
        kwargs["upstream_task_id"],
    )
    if len(xcom_value) != 0:
        return kwargs["downstream_task_id"]
