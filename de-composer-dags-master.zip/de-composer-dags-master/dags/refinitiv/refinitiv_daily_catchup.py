import os
from datetime import datetime, date, timedelta

from airflow import DAG
from airflow.operators.bash_operator import BashOperator

from slack.slack_notification import alert_task_failure

######################################################
# DAG to ingest intra day FX rates from Refinitiv API.
# Scheduled to run every hour
######################################################

env = os.environ["AIRFLOW_VAR_ENV"]

default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2020, 6, 15),
    "depends_on_past": False,
    "email_on_failure": False,
    "on_failure_callback": alert_task_failure,
}

with DAG(
    "refinitiv_daily_catchup",
    default_args=default_args,
    schedule_interval="59 01 * * *",
    catchup=False,
) as dag:

    startdatetime = str(date.today()-timedelta(days=1)) + "T00:00:00"
    enddatetime = str(date.today()-timedelta(days=1)) + "T23:59:00"
    load_refinitiv_intraday_rates = BashOperator(
        task_id="load_refinitiv_intraday_rates",
        dag=dag,
        bash_command="java "
        "-cp /home/airflow/gcs/plugins/refinitiv/refinitiv-ingestion-1.0.0.jar "
        f"-Dspring.profiles.active={env} "
        "-Dloader.main=com.ripple.data.refinitiv.IntraDayRatesRunner org.springframework.boot.loader.PropertiesLauncher "
        f"{ startdatetime } "
        f"{ enddatetime }",

    )

load_refinitiv_intraday_rates
