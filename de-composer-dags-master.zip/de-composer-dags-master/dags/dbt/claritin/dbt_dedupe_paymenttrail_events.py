import os
from datetime import datetime

from airflow import DAG, models
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from airflow.operators.dummy_operator import DummyOperator

dbt_image_path = os.environ["AIRFLOW_VAR_DBT_IMAGE_PATH"]
dbt_profiles_dir = os.environ["AIRFLOW_VAR_DBT_PROFILE_PATH"]
claritin_serv_env = os.environ["AIRFLOW_VAR_DBT_CLARITIN_SERV_ENV"]
claritin_serv_mode = os.environ["AIRFLOW_VAR_DBT_CLARITIN_SERV_MODE"]
dbt_target = os.environ["AIRFLOW_VAR_DBT_TARGET_ENV"]
nodepool = os.environ["AIRFLOW_VAR_NODEPOOL_AFFINITY"]

default_args = {
  "owner": "ripple-data",
  "depends_on_past": False,
  "start_date": datetime(2021, 5, 10),
  "email_on_failure": False,
  "email_on_retry": False,
}

# affinity constrains the nodes pods are eligible to be scheduled on
nodepool_affinity = {
  "nodeAffinity": {
    "requiredDuringSchedulingIgnoredDuringExecution": {
      "nodeSelectorTerms": [
        {
          "matchExpressions": [
            {
              "key": "cloud.google.com/gke-nodepool",
              "operator": "In",
              "values": [nodepool],
            }
          ]
        }
      ]
    }
  }
}

with models.DAG(
    dag_id="dbt_dedupe_paymenttrail_events",
    default_args=default_args,
    schedule_interval="0 */1 * * *",  # Every 1 hour
) as dag:

  start = DummyOperator(task_id="begin", dag=dag)

  dbt_run = KubernetesPodOperator(
      namespace="default",
      image=f"{dbt_image_path}",
      cmds=[
        "dbt", "run",
        "--profiles-dir", f"{dbt_profiles_dir}",
        "--target", f"{dbt_target}",
        "--model", "claritin_payment_trail_deduped",
        "--vars",
        "{'odl_event_type': \"com.ripple.rn.xrapid.XPaymentLifecycleDataEvent\", 'event_type': \"com.ripple.rn.paymentTrailEvent\", 'serv_env': "f"{claritin_serv_env}"", 'serv_mode': "f"{claritin_serv_mode}""}"],
      arguments=[],
      labels={"foo": "bar"},
      name="dbt-run",
      task_id="dbt-run-task",
      is_delete_operator_pod=True,
      affinity=nodepool_affinity,
      get_logs=True,
      dag=dag,
  )

dbt_run.set_upstream(start)
