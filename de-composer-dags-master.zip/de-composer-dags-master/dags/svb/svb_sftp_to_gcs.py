import os
from datetime import datetime

from airflow import DAG
from airflow.operators.bash_operator import BashOperator

from slack.slack_notification import alert_task_failure

env = os.environ["AIRFLOW_VAR_ENV"]
source="SFTP"
destination="GCS"
sftp_server_host="ftpprd.svb.com"
sftp_port=8022
sftp_path="/Inbox/"
sftp_gcs_bucket_name = os.environ["AIRFLOW_VAR_SVB_SRC_BUCKET"]
vault_secrets_path= os.environ["AIRFLOW_VAR_SVB_VAULT_SECRETS_PATH"]
vault_credential_key_mapping="username:username#password:password"

svb_sftp_to_gcs_jar = "data-ingestion-tool-1.0.0.jar"

default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2020, 11, 23),
    "depends_on_past": False,
    "email_on_failure": False,
    "on_failure_callback": alert_task_failure,
}

with DAG(
        "svb_sftp_to_gcs",
        default_args=default_args,
        max_active_runs=1,
        schedule_interval="0 12 * * TUE-SAT",  # runs at 12 pm utc Tuesday to Saturday
        catchup=False,
) as dag:

    move_svb_data_from_sftp_to_gcs = BashOperator(
        task_id="move_svb_data_from_sftp_to_gcs",
        dag=dag,
        bash_command=f"java -cp /home/airflow/gcs/plugins/svb/{svb_sftp_to_gcs_jar} -Dspring.profiles.active={env} "
                     f"-Dloader.main=com.ripple.data.ingestion.DataIngestionTool org.springframework.boot.loader.PropertiesLauncher "
                     f"--source={source} --destination={destination} --sftpServer={sftp_server_host} --sftpPort={sftp_port} "
                     f"--sftpPath={sftp_path} --gcsBucketName={sftp_gcs_bucket_name} --vaultSecretsPath={vault_secrets_path} "
                     f"--vaultCredentialKeyMapping={vault_credential_key_mapping}"
    )

move_svb_data_from_sftp_to_gcs