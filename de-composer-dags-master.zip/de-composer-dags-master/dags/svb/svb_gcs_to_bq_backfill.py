import os
from datetime import datetime

from airflow import DAG
from airflow.operators.bash_operator import BashOperator

from slack.slack_notification import alert_task_failure

env = os.environ["AIRFLOW_VAR_ENV"]
etl_proj = os.environ["AIRFLOW_VAR_ETL_PROJ"]
input_source_bucket = os.environ["AIRFLOW_VAR_SVB_SRC_BUCKET"]
archive_bucket = os.environ["AIRFLOW_VAR_ETL_ARCHIVE_BUCKET"]
archive_prefix = "svb/"
svb_gcs_to_bq_jar = "svb-data-ingestion-1.0.1.jar"

default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2020, 11, 23),
    "depends_on_past": False,
    "email_on_failure": False,
    "on_failure_callback": alert_task_failure,
}

with DAG(
        "svb_gcs_to_bq_backfill",
        default_args=default_args,
        max_active_runs=1,
        schedule_interval="@once",
        catchup=False,
) as dag:

    move_svb_data_from_gcs_to_bq_backfill = BashOperator(
        task_id="move_svb_data_from_gcs_to_bq_backfill",
        dag=dag,
        bash_command=f"java -cp /home/airflow/gcs/plugins/svb/{svb_gcs_to_bq_jar} -Dspring.profiles.active={env} "
                     f"-Dloader.main=com.ripple.data.backfill.SvbDataIngestionBackFill org.springframework.boot.loader.PropertiesLauncher "
                     f"--gcsBucket={input_source_bucket} --gcsArchiveBucket={archive_bucket} --gcsArchiveDirectory={archive_prefix}"
    )


move_svb_data_from_gcs_to_bq_backfill
