import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.contrib.operators.dataflow_operator import DataFlowJavaOperator
from airflow.contrib.operators.gcs_list_operator import GoogleCloudStorageListOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import BranchPythonOperator

from dags.commons.check_file_exists import file_exists
from slack.slack_notification import alert_task_failure

etl_proj = os.environ["AIRFLOW_VAR_ETL_PROJ"]
region = os.environ["AIRFLOW_VAR_ETL_REGION"]
subnet = os.environ["AIRFLOW_VAR_ETL_SUBNET"]
dflow_store = os.environ["AIRFLOW_VAR_ETL_DFLOW_STORE"]
xr_sa_email = os.environ["AIRFLOW_VAR_XR_SA"]
dflow_code_bucket = os.environ["AIRFLOW_VAR_ETL_DFLOW_CODE_BUCKET"]
dflow_kms_key = os.environ["AIRFLOW_VAR_ETL_DFLOW_KMS_KEY"]
archive_bucket = os.environ["AIRFLOW_VAR_ETL_ARCHIVE_BUCKET"]
xr_bucket = os.environ["AIRFLOW_VAR_XR_SRC_BUCKET"]

default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2019, 11, 25),
    "depends_on_past": False,
    "email_on_failure": False,
    "on_failure_callback": alert_task_failure,
    "dataflow_default_options": {
        "project": f"{etl_proj}",
        "region": f"{region}",
        "tempLocation": f"gs://{dflow_store}/xrapid-odl/tmp",
        "stagingLocation": f"gs://{dflow_store}/xrapid-odl/stg/incentive_transactions",
        "subnetwork": f"regions/{region}/subnetworks/{subnet}",
        "dataflowKmsKey": f"projects/{etl_proj}/locations/{region}/keyRings/{dflow_kms_key}/cryptoKeys/dataflow-pipeline-state-key",
        "serviceAccount": f"{xr_sa_email}@{etl_proj}.iam.gserviceaccount.com",
        "usePublicIps": "false",
    },
}

with DAG(
    "xr-incentivetransactions_ingestion",
    default_args=default_args,
    schedule_interval="20 * * * *",
    catchup=False,
) as dag:
    get_pbFiles = GoogleCloudStorageListOperator(
        task_id="get_pbFiles",
        trigger_rule="all_done",
        bucket=f"{dflow_store}",
        prefix="xrapid-odl/stg/incentive_transactions/pipeline-",
        delimiter=".pb",
        google_cloud_storage_conn_id="google_cloud_default",
    )

    branch_pb_file = BranchPythonOperator(
        task_id="branching_pb",
        python_callable=file_exists,
        op_kwargs={
            "upstream_task_id": "get_pbFiles",
            "downstream_task_id": "cleanup_pb_files",
        },
        provide_context=True,
    )

    cleanup = BashOperator(
        task_id="cleanup_pb_files",
        trigger_rule="all_done",
        bash_command="gsutil rm "
        + f"gs://{dflow_store}/"
        + '{{  task_instance.xcom_pull(task_ids=["get_pbFiles"])[0][0] }}',
    )

    get_gcsFiles = GoogleCloudStorageListOperator(
        task_id="get_gcsFiles",
        bucket=f"{xr_bucket}",
        prefix="incentive-transactions/incentive-transactions",
        delimiter=".csv",
        google_cloud_storage_conn_id="google_cloud_default",
    )

    branch_source_file = BranchPythonOperator(
        task_id="branching_source_file",
        python_callable=file_exists,
        op_kwargs={
            "upstream_task_id": "get_gcsFiles",
            "downstream_task_id": "xr-incentivetransactions_to_bq",
        },
        provide_context=True,
    )

    execution_task = DataFlowJavaOperator(
        task_id="xr-incentivetransactions_to_bq",
        jar=f"gs://{dflow_code_bucket}/xrapid-odl/xrapid-etl-1.2.2.jar",
        job_class="com.ripple.data.beam.incentives.IncentiveTransactionsToBigQuery",
        dataflow_default_options=default_args["dataflow_default_options"],
        options={
            "incentiveTransactionsFilename": '{{ task_instance.xcom_pull(task_ids=["get_gcsFiles"])[0][0] }}',
            "incentivesBucketURL": f"gs://{xr_bucket}",
            "archiveBucket": f"gs://{archive_bucket}",
            "incentiveTransactionsBigQueryTablename": "xrapid.incentive_transactions",
            "runtime": "{{ ts }}",
        },
        dag=dag,
    )

    archive_gcs_file = BashOperator(
        task_id="archive_gcs_files",
        trigger_rule="all_success",
        bash_command="gsutil mv "
        + f"gs://{xr_bucket}/"
        + '"{{ task_instance.xcom_pull(task_ids=["get_gcsFiles"])[0][0] }}"'
        + " "
        + f"gs://{archive_bucket}/xrapid/incentive_transactions/2020/",
    )

get_gcsFiles >> branch_source_file >> execution_task >> archive_gcs_file >> get_pbFiles >> branch_pb_file >> cleanup
