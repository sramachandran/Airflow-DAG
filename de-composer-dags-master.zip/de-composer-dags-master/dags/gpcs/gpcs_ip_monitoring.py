import os
from datetime import datetime

from airflow import DAG, settings
from airflow.contrib.operators.gcs_download_operator import (
    GoogleCloudStorageDownloadOperator,
)
from airflow.hooks.http_hook import HttpHook
from airflow.models import Connection
from airflow.operators.bash_operator import BashOperator
from airflow.operators.http_operator import SimpleHttpOperator
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago

from slack.slack_notification import alert_task_failure

conn = Connection(
    conn_id="gpcs_conn_id",
    conn_type="http",
    host="https://gpcs-ip-portal.ops.ripple.com",
)  # create a connection object for GPCS if it does not exist


def list_connections(**context):
    session = settings.Session()
    if not session.query(Connection).filter(Connection.conn_id == conn.conn_id).first():
        session.add(conn)
        session.commit()


def process_ips(**context):
    import sys
    import pandas as pd
    from pandas.io.json import json_normalize

    payload = context["ti"].xcom_pull(task_ids="get_gpcs_ip", key="return_value")
    print("Payload Received")
    # Use memory store of GPCS addresses to store JSON
    json = pd.read_json(payload)
    incoming_ips_df = (
        json_normalize(json["result"])
        .explode("addresses")
        .reset_index(drop=True)
        .drop(["address_details", "zone_subnet"], axis=1)
    )
    current_ips_df = pd.read_json(
        "/home/airflow/gcs/dags/dags/gpcs/gpcs_ip_current.json"
    )
    modified_ips_df = incoming_ips_df.merge(
        current_ips_df, how="outer", indicator=True
    ).loc[lambda x: x["_merge"] == "left_only"]
    if not modified_ips_df.empty:
        for index, row in modified_ips_df.iterrows():
            print(
                "Gateway IP addresses new IP: "
                + "Zone: "
                + row["zone"]
                + "   Address: "
                + row["addresses"]
            )
        print(modified_ips_df)
        incoming_ips_df.to_json("/home/airflow/gcs/data/gpcs_ip_latest.json")
        sys.exit(1)


default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2020, 6, 22),
    "depends_on_past": False,
    "email_on_failure": False,
    "on_failure_callback": alert_task_failure,
}

docs = """
## GPCS IP Address Monitor

#### Mission Critical

No

#### On Failure Actions

An IP that was previously listed and no longer present. View the GCS Bucket for the
respective airflow DAG and view the latest IP Addresses detected. This is located
in the `<gcs bucket name>/data/gpcs_ip_latest.json` file. In the log
file you will see a description of which exact IP Addresses from GPCS were
modified. Update the `gpcs_ip_current.json` with the new IP addresses
thorugh source control and update the dependent applications accordingly.
Additionally be sure to also update the IP address in TF as well at the
https://gitlab.ops.ripple.com/operations/gcp-techops-infrastructure/
repo in the `workspaces/gcp-techops-infrastructure/access_policy.tf`

#### Point of Contact

For any questions or concerns, please contact
[Nate Rose](mailto:nrose@ripple.com).
"""

with DAG(
    dag_id="gpcs_ip_monitoring",
    default_args=default_args,
    schedule_interval="0 */6 * * *",  # Every 6 hours
    catchup=False,
    doc_md=docs,
) as dag:
    check_connections = PythonOperator(
        task_id="check_connections",
        python_callable=list_connections,
        provide_context=True,
        dag=dag,
    )

    get_gpcs_ip = SimpleHttpOperator(
        task_id="get_gpcs_ip",
        method="GET",
        http_conn_id="gpcs_conn_id",
        endpoint="/",
        headers={"Content-Type": "application/json"},
        xcom_push=True,
        dag=dag,
    )

    py_process_ips = PythonOperator(
        task_id="py_process_ips",
        python_callable=process_ips,
        provide_context=True,
        dag=dag,
    )
check_connections >> get_gpcs_ip >> py_process_ips
