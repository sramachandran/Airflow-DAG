import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.bash_operator import BashOperator

from slack.slack_notification import alert_task_failure

######################################################
# DAG to ingest FX rates from CurrencyLayer API.
# Scheduled to run every hour at the 59th min
######################################################

env = os.environ["AIRFLOW_VAR_ENV"]

default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2020, 11, 3),
    "depends_on_past": False,
    "email_on_failure": False,
    "on_failure_callback": alert_task_failure,
    "retries": 3,
    "retry_delay": timedelta(minutes=1),
}

with DAG(
    "currencylayer_fx_rates",
    default_args=default_args,
    schedule_interval="59 * * * *",
    catchup=False,
) as dag:

    load_currencylayer_fx_rates = BashOperator(
        task_id="load_currencylayer_fx_rates",
        dag=dag,
        bash_command="java "
        "-cp /home/airflow/gcs/plugins/currencylayer/currencylayer-ingestion-1.0.0.jar "
        f"-Dspring.profiles.active={env} "
        "-Dloader.main=com.ripple.data.currencylayer.MainApp org.springframework.boot.loader.PropertiesLauncher",
    )

load_currencylayer_fx_rates
