import os
from datetime import datetime

from airflow import DAG
from airflow.contrib.operators.dataflow_operator import DataFlowJavaOperator

etl_proj = os.environ["AIRFLOW_VAR_ETL_PROJ"]
region = os.environ["AIRFLOW_VAR_ETL_REGION"]
subnet = os.environ["AIRFLOW_VAR_ETL_SUBNET"]
claritin_sa = os.environ["AIRFLOW_VAR_CLARITIN_SA"]
claritin_stream = os.environ["AIRFLOW_VAR_CLARITIN_STREAM"]
dflow_store = os.environ["AIRFLOW_VAR_ETL_DFLOW_STORE"]
dflow_code_bucket = os.environ["AIRFLOW_VAR_ETL_DFLOW_CODE_BUCKET"]
dflow_kms_key = os.environ["AIRFLOW_VAR_ETL_DFLOW_KMS_KEY"]


default_args = {
    "owner": "ripple-data",
    "start_date": datetime(2020, 5, 27),
    "depends_on_past": False,
    "email_on_failure": False,
    "dataflow_default_options": {
        "project": f"{etl_proj}",
        "region": f"{region}",
        "tempLocation": f"gs://{dflow_store}/claritin/tmp",
        "stagingLocation": f"gs://{dflow_store}/claritin/stg",
        "subnetwork": f"regions/{region}/subnetworks/{subnet}",
        "dataflowKmsKey": f"projects/{etl_proj}/locations/{region}/keyRings/{dflow_kms_key}/cryptoKeys/dataflow-pipeline-state-key",
        "serviceAccount": f"{claritin_sa}@{etl_proj}.iam.gserviceaccount.com",
        "usePublicIps": "false",
    },
}

with DAG(
    "claritin-events-stream-ingestion",
    default_args=default_args,
    schedule_interval="@once",
    catchup=False,
) as dag:

    execution_task = DataFlowJavaOperator(
        task_id="claritin-events-stream-ingestion-to-bq",
        jar=f"gs://{dflow_code_bucket}/claritin/claritin-etl-1.1.jar",
        job_class="com.ripple.data.consumer.beam.EventsToBigQuery",
        dataflow_default_options=default_args["dataflow_default_options"],
        options={
            "bigQueryTablename": f"{etl_proj}:claritin_event_lake.events_tbl",
            "stream": f"{claritin_stream}",
        },
        dag=dag,
    )

execution_task
