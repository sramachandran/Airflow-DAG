# de-composer-dags

Airflow DAGs Repository for Google Cloud composer

## Prerequisites

To contribute to this repo you must make sure you have the following tools installed:

- `git` - at least version 2.22. Follow download instructions [here](https://git-scm.com/downloads)
- `python` - Follow download instructions [here](https://docs.python-guide.org/starting/install3/osx/)
- `pip` - pip is installed with Python

### Local Setup

This project runs a styling lint git commit hook to clean up incoming commits.

<img src="images/pre_commit_framework.png" style="width:600px;"/>

To install, run `pip install -r requirements.txt` at the root directory

Once completed, run a `pre-commit install` to install the commit hook pipeline in your local repository.

> We run our [`pre-commit`](https://pre-commit.com/#intro) hooks on every commit to automatically point out issues in code such as missing semicolons, trailing whitespace, and debug statements. By pointing these issues out before code review, this allows a code reviewer to focus on the architecture of a change while not wasting time with trivial style nitpicks.

All commits will now be verified through a pipeline of scripts that format and test for linting. These include:

- [`prettier](https://github.com/prettier/prettier) - format markdown files to standardize style.
- [`autopep8`](https://github.com/pre-commit/mirrors-autopep8) - automatically formats Python code to conform to the PEP 8 style guide.
- [`seed-isort-config`](https://github.com/asottile/seed-isort-config) - Statically populate the known_third_party isort setting.
- [`isort`](https://github.com/pre-commit/mirrors-isort) - sort imports alphabetically, and automatically separated into sections and by type.
- [`black`](https://github.com/psf/black) - Black enforces formatting that conforms to PEP 8.
- [`flake8`](https://github.com/PyCQA/flake8) - enforces a pycodestyle.

> Configuration of these linters are provided in [.flake8](.flake8) and the [.isort.cfg](.isort.cfg). For more on how to adjust the settings for the linters view [flake8-docs](https://flake8.pycqa.org/en/latest/glossary.html#term-error-code) and the [isort-docs](https://github.com/timothycrosley/isort#configuring-isort)

> **If you need to run pre-commit without submitting a git commit, run:** `pre-commit run --all-files`

> **If you need to disable pre-commit, run** `export PRE_COMMIT_ALLOW_NO_CONFIG=1`

## Cloud Composer Repo CI/CD Pipeline

The Cloud Composer CICD Pipeline is an automated process that conducts testing, validation and compilation of the Airflow source code. It asserts numerous standardization to assure quality code collaboration. It consists of the following:

- Pre-Flight Python Compilation
- Quality Assurance Validation
- Unit Tests **(WIP)**
- GCS Deployment

<img src="images/cloudcomposercicd.png" style="width:600px;"/>

### Pre-Flight Python Compilation

Airflow DAGs are compiled and validated in a GitLab Runner during merge requests. The repo uses the `apache/airflow:1.10.11-python3.8` image to compile the python scripts and assure all necessary libraries/modules are referenced appropriately within the repo. When contributing, be sure to add any additional dependent airflow modules or packages to the [`requirements.txt`](requirements.txt) file in order for the runner to install respectively. If you would like to test with the image locally follow the following steps:

1. Pull the airflow image: `docker pull apache/airflow:1.10.11-python3.8`
2. Run: `docker run -it apache/airflow:1.10.11-python3.8 bash`
3. Copy the repo code to the image: `docker cp . <CONTAINER_NAME>:/opt/airflow`

### Quality Assurance Integrity Validation

Airflow DAGs are verified for quality through an additional series of tests to standardize source code and assert code quality. It consists of the following tests:

- `test_import_dags`: Tests there are no syntax issues or environment compatibility issues.
- `test_non_airflow_owner`: Tests that owners are set for all dag
- `test_same_file_and_dag_id_name`: Test that a file name and a dag_id are the same
- `test_import_time`: Tests that all DAGs can be parsed under the threshold time: 2 seconds

### Unit Testing **(WIP)**

### GCS Deployment: Storage Bucket Writing

The Pipeline writes the contents of the `dev` folder in the repo to a test Storage Bucker [`test-composer-dag-repo`](<https://console.cloud.google.com/storage/browser/test-composer-dag-repo?bucketsPageTableState=(%22GcsBucketList%22:(%22s%22:%5B(%22i%22:%22bucketListDisplayFields%2FtimeCreated%22,%22s%22:%221%22),(%22i%22:%22name%22,%22s%22:%220%22)%5D))&forceOnBucketsSortingFiltering=false&organizationId=471511075260&project=data-team-test-proj-40c0161f>) inside the test project (`data-team-test-proj`) in GCP.

To trigger the write to the test bucket navigate to project repo pipeline in GitLabs.

![](images/cicd_pipelines.png)

Select the **latest** build or the targeted build reflective of the commit you wish to view.

In the build diagram, you will be able to see if the pre-flight stage completed successfully. Once the pre-flight stage has ran successfully, you can trigger a job to write the repo contents to Google Cloud Storage.

  <img src="images/cicd_trigger.png" style="width:400px;"/>

## Markdown for DAG

- DAG Summary - Short 2-3 Sentence paragraph of project description goes here
- Mission Critical - Yes/No and a short blurb for context
- On Failure Actions - Rerun DAG? Yes/No and a short blurb for context
- Points of Contact - Multiple points of contact are preferable with area of responsibility and title if possible. If updating, make sure to include the date
- Business Use Case / Process - Lucidchart or Imgage of schematic (optional)
- Prerequisites | Dependencies | Resourcing -Some additional documentation (optional)

## **Slack Integration For Failure Notifications**

- When a Composer job fails, the failure will be notified in Slack. The channel used for notification is #data-alerts-gcp

### **Steps to enable failure notification to Slack**

- `slack` module in this project needs to be deployed to the DAGs bucket of the composer environment
- In Airflow UI, under Admin -> Variables create a variable with key as `ENVIRONMENT_NAME` and the appropriate environment name(Production/Staging) as val.
  This variable will be used in the slack notification to differentiate the environment in which the failure occurred.<br>
  <img src="images/airflow-variable.png" style="width:400px;"/>
- A Slack webhook needs to be created and connection to Slack needs to be configured with proper credentials in Airflow UI under `Admin -> Connections`<br>

  <img src="images/slack-connection.png" style="width:400px;"/>

### **DAG updates to send failure notification**

To send failure notification to slack from the DAG, add `"on_failure_callback": alert_task_failure"` to `default_args` of the DAG.
