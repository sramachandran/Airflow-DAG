import logging
import os
import time
import unittest
from pathlib import Path

from airflow.models import DagBag


"""DAG Quality Assurance Test
Airflow DAGs are verified for quality through an additional series of tests to standardize source code and assert code quality.
"""


class TestDagIntegrity(unittest.TestCase):
    """Tests DAG Syntax, compatibility with environment and load time."""

    LOAD_SECOND_THRESHOLD = 2

    def setUp(self):
        """Setup dagbag for each test."""
        self.dagbag = DagBag(
            dag_folder=os.environ.get("AIRFLOW_HOME", "~/airflow") + "/dags",
            include_examples=False,
        )

    def test_import_dags(self):
        """Tests there are no syntax issues or environment compatibility issues."""
        self.assertFalse(
            len(self.dagbag.import_errors),
            "DAG import failures. Errors: {}".format(self.dagbag.import_errors),
        )

    def test_non_airflow_owner(self):
        """Tests that owners are set for all dags."""
        for dag_id in self.dagbag.dag_ids:
            if dag_id != "airflow_monitoring":
                dag = self.dagbag.get_dag(dag_id)
                try:
                    self.assertIsNotNone(dag.owner)
                    self.assertNotEqual(dag.owner, "airflow")
                    self.assertIn("ripple-data", dag.owner)
                    logging.warning(f"VALIDATION SUCCEEDED | DAG: {dag.dag_id}")
                except AssertionError as err:
                    self.fail(f"issue validating owner for DAG {dag_id}: {err}")

    def test_same_file_and_dag_id_name(self):
        """Tests that filename matches dag_id."""
        for dag_id in self.dagbag.dag_ids:
            dag = self.dagbag.get_dag(dag_id)
            if not dag.is_subdag:
                stripped_filename = os.path.splitext(
                    Path(self.dagbag.get_dag(dag_id).filepath).name
                )[0]
                self.assertEqual(dag_id, stripped_filename)

    def test_import_time(self):
        """Test that all DAGs can be parsed under the threshold time: 2 Seconds."""
        for dag_id in self.dagbag.dag_ids:
            start = time.time()
            self.dagbag.process_file(self.dagbag.get_dag(dag_id).filepath)
            end = time.time()
            total = end - start
            self.assertLessEqual(total, self.LOAD_SECOND_THRESHOLD)


if __name__ == "__main__":
    unittest.main()
