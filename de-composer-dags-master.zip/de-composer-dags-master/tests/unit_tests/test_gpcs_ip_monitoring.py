import logging
import unittest
from datetime import datetime

import mock
import pytest
from airflow import DAG, settings
from airflow.models import Connection, DagBag, TaskInstance
from airflow.operators.python_operator import PythonOperator

from dags.gpcs.gpcs_ip_monitoring import (
    check_connections,
    list_connections,
    process_ips,
)

DAG_ID = "gpcs_ip_monitoring"
TASK_COUNT = 3
REF_TASK_ID = "download_ref_string"
DOWNLOAD_TASK_PREFIX = "download_result"
CONTEXT_CLASS_NAME = "airflow.ti_deps.dep_context"
DAG_TASK_STRUCTURE = {
    "check_connections": ["get_gpcs_ip"],
    "get_gpcs_ip": ["py_process_ips"],
    "py_process_ips": [],
}


def mock_change_ips(input_ip):
    """Mocks IPs Change"""
    new = [
        {
            "addresses": {"0": "52.194.246.212", "1": "137.83.201.114"},
            "zone": {"0": "Japan Central", "1": "US East", "2": "US East"},
        },
        {
            "addresses": {"0": "62.104.240.312", "1": "137.83.201.114"},
            "zone": {"0": "Japan Central", "1": "US East", "2": "US East"},
        },
    ]
    return new[input_ip]


# Test Unit Cases


class test_gpcs_ip_monitoring(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dagbag = DagBag()

    def assert_raises_with_message(self, error_type, msg, func, *args, **kwargs):
        """Utility method for asserting a message was produced."""
        with self.assertRaises(error_type) as context:
            func(*args, **kwargs)
        self.assertEqual(msg, str(context.exception))

    def test_dag_loaded(self):
        """Test for test_dagloading and Task Count"""
        dag = self.dagbag.get_dag(dag_id=DAG_ID)
        logging.warning(f"This us the DagBag ID: {dag.dag_id}")
        self.assertDictEqual(self.dagbag.import_errors, {})
        self.assertIsNotNone(dag)
        self.assertEqual(len(dag.tasks), TASK_COUNT)

    def assertDagDictEqual(self, source, dag):
        """Utility method called from test_task_structure"""
        self.assertEqual(dag.task_dict.keys(), source.keys())
        for task_id, downstream_list in source.items():
            self.assertTrue(
                dag.has_task(task_id), msg="Missing task_id: {} in dag".format(task_id)
            )
            task = dag.get_task(task_id)
            self.assertEqual(
                task.downstream_task_ids,
                set(downstream_list),
                msg="unexpected downstream link in {}".format(task_id),
            )

    def test_task_structure(self):
        """Test for Task Structure and downstream logic"""
        dag = self.dagbag.get_dag(dag_id=DAG_ID)
        self.assertDagDictEqual(DAG_TASK_STRUCTURE, dag)

    def test_get_gpcs_ip(self):
        """Test check_connections task that calls the list_connections method"""
        dag = self.dagbag.get_dag(dag_id=DAG_ID)
        mock_session = settings.Session()
        mock_context = Connection(
            conn_id="dummy test",
            conn_type="http",
            host="https://dummy.restapiexample.com/",
        )
        task = dag.get_task("check_connections")
        task.execute(context=mock_context)
        self.assertTrue(
            mock_session.query(mock_context).filter(
                Connection.conn_id == mock_context.conn_id
            )
        )


SUITE = unittest.TestLoader().loadTestsFromTestCase(test_gpcs_ip_monitoring)
unittest.TextTestRunner(verbosity=2).run(SUITE)
