from airflow.contrib.operators.slack_webhook_operator import SlackWebhookOperator
from airflow.hooks.base_hook import BaseHook
from airflow.models import Variable

SLACK_CONN_ID = "slack"

# Alert about task failure through SlackWebhookOperator to a slack channel
#
# 1. For the slack notification to work, a slack app needs to be created
# 2. The slack channel to be notified is configured as part of the slack app configuration
# 3. Connection to slack needs to be setup in Airflow using the slack app credentials
# 4. In the individual DAGs, "on_failure_callback" parameter of the "default_args" need to point to this method
#
# For future reference: https://medium.com/datareply/integrating-slack-alerts-in-airflow-c9dcd155105
#


def alert_task_failure(context):
    slack_webhook_token = BaseHook.get_connection(SLACK_CONN_ID).password

    # This environment variable need to be set in Airflow UI. Setting in Composer did not work
    environment = Variable.get("ENVIRONMENT_NAME", "")

    slack_msg = """
            :red_circle: Task Failure Alert:
            *Dag*: {dag}
            *Task*: {task}
            *Execution Time*: {exec_date}
            *Run Id*: {run_id}
            *Environment*: {environment}
            *Log Url*: {log_url}
            """.format(
        task=context.get("task_instance").task_id,
        dag=context.get("task_instance").dag_id,
        exec_date=context.get("execution_date"),
        run_id=context.get("dag_run").run_id,
        environment=environment,
        log_url=context.get("task_instance").log_url,
    )

    failure_alert = SlackWebhookOperator(
        task_id="slack_failure_notification",
        http_conn_id=SLACK_CONN_ID,
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username="airflow",
    )

    return failure_alert.execute(context=context)
